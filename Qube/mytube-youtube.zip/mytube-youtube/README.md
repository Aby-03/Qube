# Mytube-Youtube

A Pen created on CodePen.io. Original URL: [https://codepen.io/codewhiteweb/pen/yLxOzNB](https://codepen.io/codewhiteweb/pen/yLxOzNB).

A simple classic youtube like landing page using tailwind